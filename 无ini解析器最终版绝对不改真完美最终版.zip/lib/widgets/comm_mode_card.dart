// ════════════════════════════════════════════════════════════════
// comm_mode_card.dart — 通讯模式切换卡片
// ════════════════════════════════════════════════════════════════

import 'package:flutter/material.dart';
import '../main.dart';
import '../services/bt_manager.dart';
import '../theme/eva_theme.dart';

class CommModeCard extends StatelessWidget {
  final VoidCallback onChanged;
  const CommModeCard({super.key, required this.onChanged});

  @override
  Widget build(BuildContext context) {
    final mode = BtManager.instance.commMode;
    const modeColor = evaAmber;
    const modeTag = 'UDS';
    return EvaCard(
      title: 'COMM PROTOCOL',
      subtitle: '通信プロトコル',
      trailing: Container(
        padding: const EdgeInsets.symmetric(horizontal: 6, vertical: 2),
        decoration: BoxDecoration(
          color: modeColor.withOpacity(0.1),
          borderRadius: BorderRadius.circular(4),
          border: Border.all(color: modeColor.withOpacity(0.3))),
        child: Text(modeTag,
          style: TextStyle(fontFamily: 'monospace', fontSize: 8,
            fontWeight: FontWeight.w900, color: modeColor))),
      child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
        Container(
          width: double.infinity,
          padding: const EdgeInsets.all(8),
          decoration: BoxDecoration(
            color: DS.bg, borderRadius: BorderRadius.circular(6),
            border: Border.all(color: DS.border)),
          child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
            Text(mode.label, style: TextStyle(fontFamily: 'monospace',
              fontSize: 11, fontWeight: FontWeight.w800, color: modeColor)),
            const SizedBox(height: 2),
            Text(mode.desc, style: TextStyle(fontFamily: 'monospace',
              fontSize: 8, fontWeight: FontWeight.w600, color: DS.textDim)),
            const SizedBox(height: 4),
            Text(
              'Mercedes AMG W205 C63 / C190 GT 强化UDS超高速采样模式',
              style: TextStyle(fontFamily: 'monospace', fontSize: 7,
                fontWeight: FontWeight.w700, color: evaAmber.withOpacity(0.4))),
          ])),
        if (BtManager.instance.isConnected) Padding(
          padding: const EdgeInsets.only(top: 6),
          child: Text('⚠ 切换模式需要重新连接', style: TextStyle(fontFamily: 'monospace',
            fontSize: 8, fontWeight: FontWeight.w700, color: evaRed.withOpacity(0.6)))),
      ]));
  }
}
